"""Code generation modules."""

from pywire.compiler.codegen.generator import CodeGenerator

__all__ = ["CodeGenerator"]
