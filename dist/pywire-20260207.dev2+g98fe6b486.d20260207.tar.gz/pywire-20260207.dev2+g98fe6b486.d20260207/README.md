# pywire Core

The core framework for pywire.

<!-- INSTALL_MESSAGE_TEMPLATE_START -->
## 🚀 Quick Start

If you already have [uv](https://docs.astral.sh/uv/) installed, you can get started instantly:

```sh
uvx create-pywire-app
```

If you don't have `uv` installed or aren't sure, use our installer script which handles the setup for you:

### macOS / Linux
```sh
curl -fsSL pywire.dev/install | sh
```

### Windows (PowerShell)
```powershell
irm pywire.dev/install.ps1 | iex
```
<!-- INSTALL_MESSAGE_TEMPLATE_END -->

<!-- SUPPORT_MESSAGE_TEMPLATE_START -->
## ❤️ Support pywire

If pywire is helping you build, consider supporting the project. Donations cover documentation hosting, CI/CD runners, and the caffeine required for development.

[![GitHub Sponsor](https://img.shields.io/badge/Sponsor-pywire-ea4aaa?style=for-the-badge&logo=github-sponsors)](https://github.com/sponsors/pywire)
[![Ko-Fi](https://img.shields.io/badge/Ko--fi-reecelikesramen-ff5e5b?style=for-the-badge&logo=ko-fi)](https://ko-fi.com/reecelikesramen)

### Why sponsor?
* 🚀 Faster development of the core framework.
* 📖 Better docs and community examples.
* 🔧 Integration research.
<!-- SUPPORT_MESSAGE_TEMPLATE_END -->
